import React, { useState, useEffect } from 'react';
import { InventoryItem } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Package, AlertTriangle, DollarSign } from 'lucide-react';

const categoryColors = {
    engine: 'bg-red-100 text-red-800',
    brakes: 'bg-orange-100 text-orange-800',
    tires: 'bg-blue-100 text-blue-800',
    electrical: 'bg-yellow-100 text-yellow-800',
    fluids: 'bg-green-100 text-green-800',
    filters: 'bg-purple-100 text-purple-800',
    belts: 'bg-pink-100 text-pink-800',
    suspension: 'bg-indigo-100 text-indigo-800',
    exhaust: 'bg-gray-100 text-gray-800',
    body: 'bg-cyan-100 text-cyan-800',
    other: 'bg-slate-100 text-slate-800'
};

export default function InventoryGrid() {
    const [items, setItems] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [categoryFilter, setCategoryFilter] = useState('all');
    const [isLoading, setIsLoading] = useState(true);

    const loadItems = async () => {
        setIsLoading(true);
        const data = await InventoryItem.list('-created_date');
        setItems(data);
        setIsLoading(false);
    };

    useEffect(() => {
        loadItems();
    }, []);

    const filteredItems = items.filter(item => {
        const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            item.part_number.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
        return matchesSearch && matchesCategory;
    });

    const lowStockItems = items.filter(item => item.quantity_on_hand <= item.reorder_level);
    const totalValue = items.reduce((sum, item) => sum + (item.quantity_on_hand * item.cost_price || 0), 0);

    return (
        <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <Package className="h-5 w-5 text-blue-500" />
                            <div>
                                <p className="text-sm text-gray-600">Total Items</p>
                                <p className="text-2xl font-bold">{items.length}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <AlertTriangle className="h-5 w-5 text-orange-500" />
                            <div>
                                <p className="text-sm text-gray-600">Low Stock</p>
                                <p className="text-2xl font-bold text-orange-600">{lowStockItems.length}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <DollarSign className="h-5 w-5 text-green-500" />
                            <div>
                                <p className="text-sm text-gray-600">Total Value</p>
                                <p className="text-2xl font-bold">${totalValue.toLocaleString()}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <Package className="h-5 w-5 text-purple-500" />
                            <div>
                                <p className="text-sm text-gray-600">Categories</p>
                                <p className="text-2xl font-bold">{new Set(items.map(i => i.category)).size}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Filters */}
            <Card>
                <CardHeader>
                    <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
                        <CardTitle>Inventory Items</CardTitle>
                        <div className="flex gap-4">
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                <Input 
                                    placeholder="Search parts..." 
                                    className="pl-9 w-64"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                />
                            </div>
                            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                                <SelectTrigger className="w-48">
                                    <SelectValue placeholder="All Categories" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="all">All Categories</SelectItem>
                                    <SelectItem value="engine">Engine</SelectItem>
                                    <SelectItem value="brakes">Brakes</SelectItem>
                                    <SelectItem value="tires">Tires</SelectItem>
                                    <SelectItem value="electrical">Electrical</SelectItem>
                                    <SelectItem value="fluids">Fluids</SelectItem>
                                    <SelectItem value="filters">Filters</SelectItem>
                                    <SelectItem value="belts">Belts</SelectItem>
                                    <SelectItem value="suspension">Suspension</SelectItem>
                                    <SelectItem value="exhaust">Exhaust</SelectItem>
                                    <SelectItem value="body">Body</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                        {isLoading ? (
                            Array.from({ length: 8 }).map((_, i) => (
                                <div key={i} className="animate-pulse">
                                    <div className="bg-gray-200 h-32 rounded-lg"></div>
                                </div>
                            ))
                        ) : filteredItems.length > 0 ? (
                            filteredItems.map(item => (
                                <Card key={item.id} className="hover:shadow-lg transition-shadow">
                                    <CardContent className="p-4">
                                        <div className="flex justify-between items-start mb-2">
                                            <Badge className={categoryColors[item.category]}>
                                                {item.category}
                                            </Badge>
                                            {item.quantity_on_hand <= item.reorder_level && (
                                                <AlertTriangle className="h-4 w-4 text-orange-500" />
                                            )}
                                        </div>
                                        <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                                        <p className="text-sm text-gray-600 mb-2">Part #: {item.part_number}</p>
                                        <div className="grid grid-cols-2 gap-2 text-sm">
                                            <div>
                                                <p className="text-gray-500">On Hand</p>
                                                <p className="font-semibold">{item.quantity_on_hand}</p>
                                            </div>
                                            <div>
                                                <p className="text-gray-500">Cost</p>
                                                <p className="font-semibold">${item.cost_price || '0'}</p>
                                            </div>
                                            <div>
                                                <p className="text-gray-500">Selling</p>
                                                <p className="font-semibold">${item.selling_price || '0'}</p>
                                            </div>
                                            <div>
                                                <p className="text-gray-500">Location</p>
                                                <p className="font-semibold">{item.location || 'N/A'}</p>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            ))
                        ) : (
                            <div className="col-span-full text-center py-12">
                                <p className="text-gray-500">No items found matching your criteria.</p>
                            </div>
                        )}
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}