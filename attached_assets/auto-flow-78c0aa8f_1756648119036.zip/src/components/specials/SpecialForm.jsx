import React, { useState, useEffect } from 'react';
import { Special } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Switch } from '@/components/ui/switch';
import { Calendar as CalendarIcon, Loader2 } from 'lucide-react';
import { format } from 'date-fns';

export default function SpecialForm({ open, onOpenChange, special, onSave }) {
    const [formData, setFormData] = useState({ is_active: true });
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (special) {
            setFormData(special);
        } else {
            setFormData({
                title: '',
                description: '',
                image_url: '',
                valid_until: null,
                is_active: true
            });
        }
    }, [special, open]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const dataToSave = { 
                ...formData,
                valid_until: formData.valid_until ? new Date(formData.valid_until).toISOString().split('T')[0] : null
            };

            if (special?.id) {
                await Special.update(special.id, dataToSave);
            } else {
                await Special.create(dataToSave);
            }
            onSave();
        } catch (error) {
            console.error('Failed to save special:', error);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                    <DialogTitle>{special?.id ? 'Edit Special Offer' : 'Add New Special'}</DialogTitle>
                    <DialogDescription>
                        Fill in the details for your special offer below.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div>
                        <Label htmlFor="title">Title</Label>
                        <Input id="title" name="title" value={formData.title || ''} onChange={handleChange} required />
                    </div>
                    <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" name="description" value={formData.description || ''} onChange={handleChange} required />
                    </div>
                    <div>
                        <Label htmlFor="image_url">Image URL</Label>
                        <Input id="image_url" name="image_url" placeholder="https://images.unsplash.com/..." value={formData.image_url || ''} onChange={handleChange} />
                    </div>
                    <div>
                        <Label htmlFor="valid_until">Valid Until</Label>
                        <Popover>
                            <PopoverTrigger asChild>
                                <Button variant="outline" className="w-full justify-start text-left font-normal">
                                    <CalendarIcon className="mr-2 h-4 w-4" />
                                    {formData.valid_until ? format(new Date(formData.valid_until), 'PPP') : 'Pick a date'}
                                </Button>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0">
                                <Calendar
                                    mode="single"
                                    selected={formData.valid_until ? new Date(formData.valid_until) : null}
                                    onSelect={(date) => setFormData(prev => ({ ...prev, valid_until: date }))}
                                    initialFocus
                                />
                            </PopoverContent>
                        </Popover>
                    </div>
                    <div className="flex items-center space-x-2">
                        <Switch 
                            id="is_active" 
                            checked={formData.is_active}
                            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
                        />
                        <Label htmlFor="is_active">Offer is Active</Label>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit" disabled={isSaving}>
                            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Offer
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}