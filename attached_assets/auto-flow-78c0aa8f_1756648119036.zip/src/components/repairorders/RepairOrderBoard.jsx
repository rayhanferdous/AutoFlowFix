import React, { useState, useEffect } from 'react';
import { RepairOrder } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Vehicle } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { User, Car, DollarSign } from 'lucide-react';

const statusColumns = [
    { id: 'estimate', title: 'Estimates', color: 'bg-blue-50' },
    { id: 'approved', title: 'Approved', color: 'bg-yellow-50' },
    { id: 'in_progress', title: 'In Progress', color: 'bg-orange-50' },
    { id: 'awaiting_parts', title: 'Awaiting Parts', color: 'bg-purple-50' },
    { id: 'completed', title: 'Completed', color: 'bg-green-50' }
];

export default function RepairOrderBoard() {
    const [repairOrders, setRepairOrders] = useState([]);
    const [customers, setCustomers] = useState({});
    const [vehicles, setVehicles] = useState({});
    const [isLoading, setIsLoading] = useState(true);

    const loadData = async () => {
        setIsLoading(true);
        const [orderData, customerData, vehicleData] = await Promise.all([
            RepairOrder.list('-created_date'),
            Customer.list(),
            Vehicle.list()
        ]);
        
        setRepairOrders(orderData);
        setCustomers(customerData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));
        setVehicles(vehicleData.reduce((acc, v) => ({ ...acc, [v.id]: v }), {}));
        setIsLoading(false);
    };

    useEffect(() => {
        loadData();
    }, []);

    const handleDragEnd = async (result) => {
        if (!result.destination) return;

        const { source, destination, draggableId } = result;
        if (source.droppableId === destination.droppableId) return;

        const newStatus = destination.droppableId;
        await RepairOrder.update(draggableId, { status: newStatus });
        loadData();
    };

    const getOrdersForStatus = (status) => {
        return repairOrders.filter(order => order.status === status);
    };

    return (
        <div className="h-full overflow-x-auto">
            <DragDropContext onDragEnd={handleDragEnd}>
                <div className="flex gap-6 min-w-max p-4">
                    {statusColumns.map(column => (
                        <div key={column.id} className="flex-shrink-0 w-80">
                            <Card className={`h-full ${column.color}`}>
                                <CardHeader className="pb-3">
                                    <div className="flex justify-between items-center">
                                        <CardTitle className="text-lg">{column.title}</CardTitle>
                                        <Badge variant="secondary">
                                            {getOrdersForStatus(column.id).length}
                                        </Badge>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <Droppable droppableId={column.id}>
                                        {(provided, snapshot) => (
                                            <div
                                                {...provided.droppableProps}
                                                ref={provided.innerRef}
                                                className={`space-y-3 min-h-[200px] ${
                                                    snapshot.isDraggingOver ? 'bg-gray-100 rounded-lg' : ''
                                                }`}
                                            >
                                                {getOrdersForStatus(column.id).map((order, index) => (
                                                    <Draggable key={order.id} draggableId={order.id} index={index}>
                                                        {(provided, snapshot) => (
                                                            <Card
                                                                ref={provided.innerRef}
                                                                {...provided.draggableProps}
                                                                {...provided.dragHandleProps}
                                                                className={`cursor-move hover:shadow-md transition-shadow ${
                                                                    snapshot.isDragging ? 'rotate-3 shadow-lg' : ''
                                                                }`}
                                                            >
                                                                <CardContent className="p-4">
                                                                    <div className="flex items-start justify-between mb-2">
                                                                        <div className="text-sm font-medium text-blue-600">
                                                                            RO-{order.id.slice(-4)}
                                                                        </div>
                                                                        <div className="text-sm font-bold text-green-600">
                                                                            ${order.total_amount?.toLocaleString() || '0'}
                                                                        </div>
                                                                    </div>
                                                                    <div className="space-y-2">
                                                                        <div className="flex items-center gap-2 text-sm">
                                                                            <User className="h-4 w-4 text-gray-400" />
                                                                            <span className="truncate">
                                                                                {customers[order.customer_id]?.full_name || 'Unknown Customer'}
                                                                            </span>
                                                                        </div>
                                                                        <div className="flex items-center gap-2 text-sm">
                                                                            <Car className="h-4 w-4 text-gray-400" />
                                                                            <span className="truncate">
                                                                                {vehicles[order.vehicle_id] 
                                                                                    ? `${vehicles[order.vehicle_id].year} ${vehicles[order.vehicle_id].make} ${vehicles[order.vehicle_id].model}`
                                                                                    : 'Unknown Vehicle'
                                                                                }
                                                                            </span>
                                                                        </div>
                                                                        {order.services?.length > 0 && (
                                                                            <div className="text-xs text-gray-600 mt-2">
                                                                                {order.services.slice(0, 2).map((service, idx) => (
                                                                                    <div key={idx}>• {service.name}</div>
                                                                                ))}
                                                                                {order.services.length > 2 && (
                                                                                    <div>• +{order.services.length - 2} more</div>
                                                                                )}
                                                                            </div>
                                                                        )}
                                                                    </div>
                                                                </CardContent>
                                                            </Card>
                                                        )}
                                                    </Draggable>
                                                ))}
                                                {provided.placeholder}
                                            </div>
                                        )}
                                    </Droppable>
                                </CardContent>
                            </Card>
                        </div>
                    ))}
                </div>
            </DragDropContext>
        </div>
    );
}