import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Key } from 'lucide-react';
import { resetCustomerPassword } from '@/api/functions/resetCustomerPassword';

export default function PasswordResetTool() {
    const [email, setEmail] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [message, setMessage] = useState('');

    const handleReset = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setMessage('');

        try {
            const response = await resetCustomerPassword({
                email: email,
                newPassword: newPassword
            });

            if (response.data.success) {
                setMessage('✅ Password reset successfully! Try logging in now.');
                setEmail('');
                setNewPassword('');
            } else {
                setMessage(`❌ ${response.data.message}`);
            }
        } catch (error) {
            setMessage('❌ Failed to reset password');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Card className="w-full max-w-md">
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5" />
                    Reset Customer Password
                </CardTitle>
            </CardHeader>
            <CardContent>
                <form onSubmit={handleReset} className="space-y-4">
                    <div>
                        <Label htmlFor="email">Customer Email</Label>
                        <Input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="customer@email.com"
                            required
                        />
                    </div>
                    <div>
                        <Label htmlFor="newPassword">New Password</Label>
                        <Input
                            id="newPassword"
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="Enter new password"
                            required
                            minLength="6"
                        />
                    </div>
                    <Button type="submit" disabled={isLoading} className="w-full">
                        {isLoading ? (
                            <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Resetting...
                            </>
                        ) : (
                            'Reset Password'
                        )}
                    </Button>
                    {message && (
                        <div className="text-sm p-3 rounded-lg bg-gray-50">
                            {message}
                        </div>
                    )}
                </form>
            </CardContent>
        </Card>
    );
}