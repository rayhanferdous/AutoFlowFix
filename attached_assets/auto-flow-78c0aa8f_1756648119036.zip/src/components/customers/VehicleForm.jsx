import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Vehicle } from '@/api/entities';
import { Loader2 } from 'lucide-react';

export default function VehicleForm({ open, onOpenChange, vehicle, customerId, onSave }) {
    const [formData, setFormData] = useState({ year: new Date().getFullYear() });
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (vehicle) {
            setFormData(vehicle);
        } else {
            setFormData({
                make: '',
                model: '',
                year: new Date().getFullYear(),
                vin: '',
                license_plate: '',
                mileage: '',
                notes: ''
            });
        }
    }, [vehicle, open]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            const dataToSave = { ...formData, customer_id: customerId, year: Number(formData.year), mileage: Number(formData.mileage) || 0 };
            if (vehicle?.id) {
                await Vehicle.update(vehicle.id, dataToSave);
            } else {
                await Vehicle.create(dataToSave);
            }
            onSave();
        } catch (error) {
            console.error('Failed to save vehicle', error);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>{vehicle?.id ? 'Edit Vehicle' : 'Add New Vehicle'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4 py-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <Label htmlFor="make">Make</Label>
                            <Input id="make" name="make" value={formData.make || ''} onChange={handleChange} required />
                        </div>
                        <div>
                            <Label htmlFor="model">Model</Label>
                            <Input id="model" name="model" value={formData.model || ''} onChange={handleChange} required />
                        </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                         <div>
                            <Label htmlFor="year">Year</Label>
                            <Input id="year" name="year" type="number" value={formData.year || ''} onChange={handleChange} required />
                        </div>
                        <div>
                            <Label htmlFor="license_plate">License Plate</Label>
                            <Input id="license_plate" name="license_plate" value={formData.license_plate || ''} onChange={handleChange} />
                        </div>
                    </div>
                     <div>
                        <Label htmlFor="vin">VIN</Label>
                        <Input id="vin" name="vin" value={formData.vin || ''} onChange={handleChange} />
                    </div>
                    <div>
                        <Label htmlFor="mileage">Mileage</Label>
                        <Input id="mileage" name="mileage" type="number" value={formData.mileage || ''} onChange={handleChange} />
                    </div>
                    <DialogFooter>
                         <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit" disabled={isSaving}>
                            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Vehicle
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}