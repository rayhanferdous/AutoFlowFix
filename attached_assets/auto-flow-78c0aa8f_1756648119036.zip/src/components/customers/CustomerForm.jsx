
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea'; // Fixed typo here: removed 's' after 'Textarea}'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Customer } from '@/api/entities';
import { Loader2 } from 'lucide-react';

export default function CustomerForm({ open, onOpenChange, customer, onSave }) {
    const [formData, setFormData] = useState({});
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        if (customer) {
            const initialData = { ...customer };
            if (initialData.address && typeof initialData.address === 'object') {
                const { street, city, state, zip_code } = initialData.address;
                initialData.address = [street, city, state, zip_code].filter(Boolean).join(', ');
            }
            setFormData(initialData);
        } else {
            setFormData({
                full_name: '',
                email: '',
                phone_number: '',
                address: '',
                notes: ''
            });
        }
    }, [customer, open]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSaving(true);
        try {
            if (customer?.id) {
                await Customer.update(customer.id, formData);
            } else {
                await Customer.create(formData);
            }
            onSave();
        } catch (error) {
            console.error('Failed to save customer', error);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle>{customer?.id ? 'Edit Customer' : 'Add New Customer'}</DialogTitle>
                    <DialogDescription>
                        Enter the customer's details below. Click save when you're done.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="full_name" className="text-right">Full Name</Label>
                            <Input id="full_name" name="full_name" value={formData.full_name || ''} onChange={handleChange} className="col-span-3" required />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="email" className="text-right">Email</Label>
                            <Input id="email" name="email" type="email" value={formData.email || ''} onChange={handleChange} className="col-span-3" required />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="phone_number" className="text-right">Phone</Label>
                            <Input id="phone_number" name="phone_number" value={formData.phone_number || ''} onChange={handleChange} className="col-span-3" />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="address" className="text-right">Address</Label>
                            <Input id="address" name="address" value={formData.address || ''} onChange={handleChange} className="col-span-3" />
                        </div>
                         <div className="grid grid-cols-4 items-start gap-4">
                            <Label htmlFor="notes" className="text-right mt-2">Notes</Label>
                            <Textarea id="notes" name="notes" value={formData.notes || ''} onChange={handleChange} className="col-span-3" />
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                        <Button type="submit" disabled={isSaving}>
                            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Save Customer
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
