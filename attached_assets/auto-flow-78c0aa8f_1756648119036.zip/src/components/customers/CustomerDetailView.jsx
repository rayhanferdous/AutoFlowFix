
import React, { useState, useEffect } from 'react';
import { Vehicle } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Appointment } from '@/api/entities';
import { RepairOrder } from '@/api/entities';
import { Invoice } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Mail, Phone, Home, Car, Plus, Edit, Trash2, Milestone, Loader2 } from 'lucide-react';
import VehicleForm from './VehicleForm';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

export default function CustomerDetailView({ customer, onEditCustomer, onDeleteCustomer }) {
    const [vehicles, setVehicles] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isVehicleFormOpen, setIsVehicleFormOpen] = useState(false);
    const [editingVehicle, setEditingVehicle] = useState(null);
    const [isDeleting, setIsDeleting] = useState(false);

    const formatAddress = (address) => {
        if (!address) return 'N/A';
        if (typeof address === 'string') return address;
        if (typeof address === 'object' && address !== null) {
            return [address.street, address.city, address.state, address.zip_code].filter(Boolean).join(', ');
        }
        return 'N/A';
    };

    const loadVehicles = async () => {
        if (!customer?.id) return;
        setIsLoading(true);
        const data = await Vehicle.filter({ customer_id: customer.id }, '-created_date');
        setVehicles(data);
        setIsLoading(false);
    };

    useEffect(() => {
        loadVehicles();
    }, [customer]);

    const handleEditVehicle = (vehicle) => {
        setEditingVehicle(vehicle);
        setIsVehicleFormOpen(true);
    }
    
    const handleAddVehicle = () => {
        setEditingVehicle(null);
        setIsVehicleFormOpen(true);
    }

    const handleSaveVehicle = () => {
        setIsVehicleFormOpen(false);
        loadVehicles();
    }

    const handleDelete = async () => {
        if (!customer) return;
        setIsDeleting(true);
        try {
            // Cascade delete: remove all data associated with the customer.
            const [vehiclesToDelete, appointmentsToDelete, repairOrdersToDelete, invoicesToDelete] = await Promise.all([
                Vehicle.filter({ customer_id: customer.id }),
                Appointment.filter({ customer_id: customer.id }),
                RepairOrder.filter({ customer_id: customer.id }),
                Invoice.filter({ customer_id: customer.id })
            ]);

            const deletePromises = [
                ...vehiclesToDelete.map(v => Vehicle.delete(v.id)),
                ...appointmentsToDelete.map(a => Appointment.delete(a.id)),
                ...repairOrdersToDelete.map(ro => RepairOrder.delete(ro.id)),
                ...invoicesToDelete.map(i => Invoice.delete(i.id))
            ];
            await Promise.all(deletePromises);
            
            await Customer.delete(customer.id);
            
            if (onDeleteCustomer) {
                onDeleteCustomer();
            }

        } catch (error) {
            console.error("Failed to delete customer and related data:", error);
        } finally {
            setIsDeleting(false);
        }
    };
    
    if (!customer) {
        return (
            <div className="h-full flex flex-col items-center justify-center bg-gray-50 rounded-lg">
                <Car className="h-16 w-16 text-gray-300" />
                <p className="mt-4 text-gray-500">Select a customer to view their details.</p>
            </div>
        )
    }

    return (
        <div className="p-1 space-y-6">
            <Card>
                <CardHeader className="flex flex-row justify-between items-start">
                    <div>
                        <CardTitle className="text-2xl">{customer.full_name}</CardTitle>
                        <CardDescription>Customer since {new Date(customer.created_date).toLocaleDateString()}</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm" onClick={onEditCustomer}><Edit className="h-3 w-3 mr-2" /> Edit</Button>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button variant="destructive" size="sm"><Trash2 className="h-3 w-3 mr-2" /> Delete</Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                    <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                        This action cannot be undone. This will permanently delete the customer
                                        and all of their associated data, including vehicles, appointments,
                                        repair orders, and invoices.
                                    </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
                                        {isDeleting ? (
                                            <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Deleting...</>
                                        ) : (
                                            "Yes, delete this customer"
                                        )}
                                    </AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                    </div>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-4 text-sm">
                    <div className="flex items-start gap-3">
                        <Mail className="h-4 w-4 mt-1 text-gray-400" />
                        <div>
                            <p className="font-semibold">Email</p>
                            <p className="text-gray-600">{customer.email}</p>
                        </div>
                    </div>
                     <div className="flex items-start gap-3">
                        <Phone className="h-4 w-4 mt-1 text-gray-400" />
                        <div>
                            <p className="font-semibold">Phone</p>
                            <p className="text-gray-600">{customer.phone_number || 'N/A'}</p>
                        </div>
                    </div>
                     <div className="flex items-start gap-3 col-span-2">
                        <Home className="h-4 w-4 mt-1 text-gray-400" />
                        <div>
                            <p className="font-semibold">Address</p>
                            <p className="text-gray-600">{formatAddress(customer.address)}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

             <Card>
                <CardHeader className="flex flex-row justify-between items-center">
                    <CardTitle className="text-xl">Vehicles</CardTitle>
                    <Button size="sm" onClick={handleAddVehicle}><Plus className="h-4 w-4 mr-2" /> Add Vehicle</Button>
                </CardHeader>
                <CardContent className="space-y-4">
                    {isLoading ? (
                         <Skeleton className="h-20 w-full" />
                    ) : vehicles.length > 0 ? (
                        vehicles.map(vehicle => (
                            <div key={vehicle.id} className="p-4 border rounded-lg flex justify-between items-center">
                               <div>
                                   <p className="font-bold text-lg text-gray-800">{vehicle.year} {vehicle.make} {vehicle.model}</p>
                                   <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                                       <span>VIN: {vehicle.vin || 'N/A'}</span>
                                       <span>Plate: {vehicle.license_plate || 'N/A'}</span>
                                       <span><Milestone className="inline h-3 w-3 mr-1" />{vehicle.mileage?.toLocaleString() || 0} mi</span>
                                   </div>
                               </div>
                               <div>
                                   <Button variant="ghost" size="icon" onClick={() => handleEditVehicle(vehicle)}><Edit className="h-4 w-4" /></Button>
                               </div>
                            </div>
                        ))
                    ) : (
                        <p className="text-center text-gray-500 py-4">No vehicles found for this customer.</p>
                    )}
                </CardContent>
            </Card>

            <VehicleForm 
                open={isVehicleFormOpen}
                onOpenChange={setIsVehicleFormOpen}
                vehicle={editingVehicle}
                customerId={customer.id}
                onSave={handleSaveVehicle}
            />
        </div>
    );
}
