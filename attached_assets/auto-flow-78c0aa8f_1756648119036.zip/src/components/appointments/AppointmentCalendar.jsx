import React, { useState, useEffect } from 'react';
import { Appointment } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Vehicle } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Clock, User, Car } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths, startOfWeek, endOfWeek } from 'date-fns';

const statusColors = {
    scheduled: 'bg-blue-100 text-blue-800 border-blue-200',
    checked_in: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    in_progress: 'bg-orange-100 text-orange-800 border-orange-200',
    completed: 'bg-green-100 text-green-800 border-green-200',
    cancelled: 'bg-red-100 text-red-800 border-red-200',
    no_show: 'bg-gray-100 text-gray-800 border-gray-200'
};

export default function AppointmentCalendar({ onAppointmentSelect }) {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [appointments, setAppointments] = useState([]);
    const [customers, setCustomers] = useState({});
    const [vehicles, setVehicles] = useState({});
    const [isLoading, setIsLoading] = useState(true);

    const loadData = async () => {
        setIsLoading(true);
        const [appointmentData, customerData, vehicleData] = await Promise.all([
            Appointment.list('-appointment_date'),
            Customer.list(),
            Vehicle.list()
        ]);
        
        setAppointments(appointmentData);
        setCustomers(customerData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));
        setVehicles(vehicleData.reduce((acc, v) => ({ ...acc, [v.id]: v }), {}));
        setIsLoading(false);
    };

    useEffect(() => {
        loadData();
    }, []);

    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const calendarStart = startOfWeek(monthStart);
    const calendarEnd = endOfWeek(monthEnd);
    const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

    const getAppointmentsForDay = (day) => {
        return appointments.filter(apt => 
            isSameDay(new Date(apt.appointment_date), day)
        );
    };

    return (
        <Card className="h-full">
            <CardHeader>
                <div className="flex items-center justify-between">
                    <CardTitle className="text-xl">{format(currentDate, 'MMMM yyyy')}</CardTitle>
                    <div className="flex gap-2">
                        <Button variant="outline" size="icon" onClick={() => setCurrentDate(subMonths(currentDate, 1))}>
                            <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="icon" onClick={() => setCurrentDate(addMonths(currentDate, 1))}>
                            <ChevronRight className="h-4 w-4" />
                        </Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-7 gap-1 mb-4">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                        <div key={day} className="p-2 text-center font-medium text-gray-500 text-sm">
                            {day}
                        </div>
                    ))}
                </div>
                <div className="grid grid-cols-7 gap-1">
                    {calendarDays.map(day => {
                        const dayAppointments = getAppointmentsForDay(day);
                        const isCurrentMonth = isSameMonth(day, currentDate);
                        const isToday = isSameDay(day, new Date());
                        
                        return (
                            <div 
                                key={day.toISOString()} 
                                className={`min-h-[100px] p-1 border rounded-md ${
                                    isCurrentMonth ? 'bg-white' : 'bg-gray-50'
                                } ${isToday ? 'ring-2 ring-blue-400' : ''}`}
                            >
                                <div className={`text-sm font-medium ${
                                    isCurrentMonth ? 'text-gray-900' : 'text-gray-400'
                                } ${isToday ? 'text-blue-600' : ''}`}>
                                    {format(day, 'd')}
                                </div>
                                <div className="space-y-1 mt-1">
                                    {dayAppointments.slice(0, 2).map(apt => (
                                        <div
                                            key={apt.id}
                                            onClick={() => onAppointmentSelect?.(apt)}
                                            className={`text-xs p-1 rounded cursor-pointer hover:opacity-80 ${statusColors[apt.status]}`}
                                        >
                                            <div className="font-medium truncate">
                                                {format(new Date(apt.appointment_date), 'HH:mm')}
                                            </div>
                                            <div className="truncate">
                                                {customers[apt.customer_id]?.full_name || 'Unknown'}
                                            </div>
                                        </div>
                                    ))}
                                    {dayAppointments.length > 2 && (
                                        <div className="text-xs text-gray-500 text-center">
                                            +{dayAppointments.length - 2} more
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </CardContent>
        </Card>
    );
}