import React, { useState, useEffect } from 'react';
import { Invoice } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, FileText, DollarSign, Calendar, User } from 'lucide-react';
import { format } from 'date-fns';

const statusColors = {
    draft: 'bg-gray-100 text-gray-800',
    sent: 'bg-blue-100 text-blue-800',
    paid: 'bg-green-100 text-green-800',
    overdue: 'bg-red-100 text-red-800'
};

export default function InvoiceList() {
    const [invoices, setInvoices] = useState([]);
    const [customers, setCustomers] = useState({});
    const [searchTerm, setSearchTerm] = useState('');
    const [isLoading, setIsLoading] = useState(true);

    const loadData = async () => {
        setIsLoading(true);
        const [invoiceData, customerData] = await Promise.all([
            Invoice.list('-created_date'),
            Customer.list()
        ]);
        
        setInvoices(invoiceData);
        setCustomers(customerData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}));
        setIsLoading(false);
    };

    useEffect(() => {
        loadData();
    }, []);

    const filteredInvoices = invoices.filter(invoice => {
        const customer = customers[invoice.customer_id];
        return (
            invoice.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
            customer?.full_name.toLowerCase().includes(searchTerm.toLowerCase())
        );
    });

    const totalAmount = filteredInvoices.reduce((sum, inv) => sum + inv.total_amount, 0);
    const paidAmount = filteredInvoices.reduce((sum, inv) => sum + inv.paid_amount, 0);
    const pendingAmount = totalAmount - paidAmount;

    return (
        <div className="space-y-6">
            {/* Summary Cards */}
            <div className="grid md:grid-cols-4 gap-4">
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <FileText className="h-5 w-5 text-blue-500" />
                            <div>
                                <p className="text-sm text-gray-600">Total Invoices</p>
                                <p className="text-2xl font-bold">{filteredInvoices.length}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <DollarSign className="h-5 w-5 text-green-500" />
                            <div>
                                <p className="text-sm text-gray-600">Total Amount</p>
                                <p className="text-2xl font-bold">${totalAmount.toLocaleString()}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <DollarSign className="h-5 w-5 text-green-600" />
                            <div>
                                <p className="text-sm text-gray-600">Paid</p>
                                <p className="text-2xl font-bold text-green-600">${paidAmount.toLocaleString()}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                            <DollarSign className="h-5 w-5 text-orange-500" />
                            <div>
                                <p className="text-sm text-gray-600">Pending</p>
                                <p className="text-2xl font-bold text-orange-600">${pendingAmount.toLocaleString()}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Invoice Table */}
            <Card>
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <CardTitle>All Invoices</CardTitle>
                        <div className="relative w-64">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                            <Input 
                                placeholder="Search invoices..." 
                                className="pl-9"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Invoice #</TableHead>
                                <TableHead>Customer</TableHead>
                                <TableHead>Date</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead>Paid</TableHead>
                                <TableHead>Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {isLoading ? (
                                <TableRow>
                                    <TableCell colSpan={6} className="text-center py-8">Loading...</TableCell>
                                </TableRow>
                            ) : filteredInvoices.length > 0 ? (
                                filteredInvoices.map(invoice => (
                                    <TableRow key={invoice.id} className="cursor-pointer hover:bg-gray-50">
                                        <TableCell className="font-mono font-medium">
                                            {invoice.invoice_number}
                                        </TableCell>
                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                <User className="h-4 w-4 text-gray-400" />
                                                {customers[invoice.customer_id]?.full_name || 'Unknown'}
                                            </div>
                                        </TableCell>
                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                <Calendar className="h-4 w-4 text-gray-400" />
                                                {format(new Date(invoice.invoice_date), 'MMM d, yyyy')}
                                            </div>
                                        </TableCell>
                                        <TableCell className="font-medium">
                                            ${invoice.total_amount.toLocaleString()}
                                        </TableCell>
                                        <TableCell className="font-medium text-green-600">
                                            ${invoice.paid_amount.toLocaleString()}
                                        </TableCell>
                                        <TableCell>
                                            <Badge className={statusColors[invoice.status]}>
                                                {invoice.status}
                                            </Badge>
                                        </TableCell>
                                    </TableRow>
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                                        No invoices found
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    );
}