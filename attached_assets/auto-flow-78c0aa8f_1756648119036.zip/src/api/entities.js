import { base44 } from './base44Client';


export const Customer = base44.entities.Customer;

export const Vehicle = base44.entities.Vehicle;

export const Appointment = base44.entities.Appointment;

export const RepairOrder = base44.entities.RepairOrder;

export const Invoice = base44.entities.Invoice;

export const InventoryItem = base44.entities.InventoryItem;

export const Special = base44.entities.Special;

export const PortalUser = base44.entities.PortalUser;

export const TestAccount = base44.entities.TestAccount;

export const CustomerPortalAccount = base44.entities.CustomerPortalAccount;



// auth sdk:
export const User = base44.auth;