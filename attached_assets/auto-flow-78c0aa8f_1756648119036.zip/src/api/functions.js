import { base44 } from './base44Client';


export const customerAuth = base44.functions.customerAuth;

