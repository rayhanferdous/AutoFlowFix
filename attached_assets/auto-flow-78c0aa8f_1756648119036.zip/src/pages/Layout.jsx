

import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Home, Users, Wrench, Calendar, Car, ScrollText, Settings, Menu, HardHat, Tag, Info, LayoutDashboard, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

const mainNavItems = [
  { title: 'Dashboard', icon: Home, page: 'Dashboard' },
  { title: 'Appointments', icon: Calendar, page: 'Appointments' },
  { title: 'Customers', icon: Users, page: 'Customers' },
  { title: 'Repair Orders', icon: Wrench, page: 'RepairOrders' },
  { title: 'Invoices', icon: ScrollText, page: 'Invoices' },
  { title: 'Inventory', icon: HardHat, page: 'Inventory' },
];

const customerNavItems = [
    { title: 'New Customer Registration', icon: UserPlus, page: 'CustomerRegistration' },
    { title: 'Customer Portal', icon: LayoutDashboard, page: 'CustomerPortal'}
];

const secondaryNavItems = [
    { title: 'Weekly Specials', icon: Tag, page: 'WeeklySpecials' },
    { title: 'About Us', icon: Info, page: 'AboutUs' },
    { title: 'Debug Customer', icon: Info, page: 'CustomerDebug' },
];

const NavContent = ({ pathname, onLinkClick }) => (
    <>
      <nav className="flex flex-col gap-2 p-4">
        <p className="px-4 pt-2 pb-1 text-xs font-semibold text-gray-400 uppercase">Management</p>
        {mainNavItems.map((item) => {
          const url = createPageUrl(item.page);
          const isActive = pathname === url;
          return (
            <Link key={item.title} to={url} onClick={onLinkClick}>
              <Button
                variant={isActive ? 'secondary' : 'ghost'}
                className="w-full justify-start gap-3 text-base h-12"
              >
                <item.icon className={`h-5 w-5 ${isActive ? 'text-blue-500' : 'text-gray-500'}`} />
                {item.title}
              </Button>
            </Link>
          );
        })}
      </nav>
      
      <nav className="flex flex-col gap-2 p-4 border-t">
        <p className="px-4 pt-2 pb-1 text-xs font-semibold text-gray-400 uppercase">For Customers</p>
        {customerNavItems.map((item) => {
            const url = createPageUrl(item.page);
            const isActive = pathname === url;
            return (
                <Link key={item.title} to={url} onClick={onLinkClick}>
                <Button
                    variant={isActive ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3 text-base h-12"
                >
                    <item.icon className={`h-5 w-5 ${isActive ? 'text-blue-500' : 'text-gray-500'}`} />
                    {item.title}
                </Button>
                </Link>
            );
        })}
      </nav>

      <nav className="flex flex-col gap-2 p-4 border-t">
        <p className="px-4 pt-2 pb-1 text-xs font-semibold text-gray-400 uppercase">Pages</p>
        {secondaryNavItems.map((item) => {
            const url = createPageUrl(item.page);
            const isActive = pathname === url;
            return (
                <Link key={item.title} to={url} onClick={onLinkClick}>
                <Button
                    variant={isActive ? 'secondary' : 'ghost'}
                    className="w-full justify-start gap-3 text-base h-12"
                >
                    <item.icon className={`h-5 w-5 ${isActive ? 'text-blue-500' : 'text-gray-500'}`} />
                    {item.title}
                </Button>
                </Link>
            );
        })}
      </nav>
    </>
);

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isSheetOpen, setIsSheetOpen] = React.useState(false);

  return (
    <div className="min-h-screen w-full bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r bg-white">
        <div className="p-6 border-b flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
             <Car className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-xl font-bold text-gray-800">AutoFlow</h1>
        </div>
        <div className="flex-1 flex flex-col">
           <NavContent pathname={location.pathname} />
        </div>
         <div className="p-4 border-t">
            <Button variant="ghost" className="w-full justify-start gap-3 text-base h-12">
              <Settings className="h-5 w-5 text-gray-500" />
              Settings
            </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col">
        {/* Mobile Header */}
        <header className="md:hidden flex items-center justify-between p-4 border-b bg-white sticky top-0 z-10">
          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
               <div className="p-6 border-b flex items-center gap-3">
                 <div className="bg-blue-600 p-2 rounded-lg">
                   <Car className="h-6 w-6 text-white" />
                 </div>
                 <h1 className="text-xl font-bold text-gray-800">AutoFlow</h1>
               </div>
               <NavContent pathname={location.pathname} onLinkClick={() => setIsSheetOpen(false)} />
            </SheetContent>
          </Sheet>
          <h1 className="text-lg font-bold">{currentPageName}</h1>
          <div className="w-10"></div>
        </header>
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}

