import React, { useState, useEffect } from 'react';
import { Appointment } from '@/api/entities';
import { Customer } from '@/api/entities';
import { Vehicle } from '@/api/entities';
import { RepairOrder } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Plus, Calendar, Users, Wrench, Clock, User, Car } from 'lucide-react';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format, isToday, isTomorrow, addDays, isAfter } from 'date-fns';

const StatCard = ({ title, value, icon: Icon, color }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-gray-500">{title}</CardTitle>
      <Icon className={`h-5 w-5 ${color}`} />
    </CardHeader>
    <CardContent>
      <div className="text-3xl font-bold text-gray-800">{value}</div>
    </CardContent>
  </Card>
);

const statusColors = {
    scheduled: 'bg-blue-100 text-blue-800',
    checked_in: 'bg-yellow-100 text-yellow-800',
    in_progress: 'bg-orange-100 text-orange-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
    no_show: 'bg-gray-100 text-gray-800'
};

export default function Dashboard() {
  const [appointments, setAppointments] = useState([]);
  const [customers, setCustomers] = useState({});
  const [vehicles, setVehicles] = useState({});
  const [repairOrders, setRepairOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const [appointmentData, customerData, vehicleData, repairOrderData] = await Promise.all([
          Appointment.list('-appointment_date', 50),
          Customer.list(),
          Vehicle.list(),
          RepairOrder.list('-created_date', 20)
        ]);
        
        setAppointments(appointmentData || []);
        setCustomers(customerData ? customerData.reduce((acc, c) => ({ ...acc, [c.id]: c }), {}) : {});
        setVehicles(vehicleData ? vehicleData.reduce((acc, v) => ({ ...acc, [v.id]: v }), {}) : {});
        setRepairOrders(repairOrderData || []);
        setIsLoading(false);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
        setIsLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  const now = new Date();
  const todayAppointments = appointments.filter(apt => {
    try {
      return isToday(new Date(apt.appointment_date));
    } catch {
      return false;
    }
  });
  
  const tomorrowAppointments = appointments.filter(apt => {
    try {
      return isTomorrow(new Date(apt.appointment_date));
    } catch {
      return false;
    }
  });
  
  const openRepairOrders = repairOrders.filter(ro => 
    ['estimate', 'approved', 'in_progress', 'awaiting_parts'].includes(ro.status)
  );
  
  const thisWeekCustomers = customers ? Object.values(customers).filter(c => {
    try {
      const created = new Date(c.created_date);
      const weekAgo = addDays(new Date(), -7);
      return created >= weekAgo;
    } catch {
      return false;
    }
  }) : [];

  // Get upcoming appointments (today and next 7 days)
  const upcomingAppointments = appointments.filter(apt => {
    try {
      const aptDate = new Date(apt.appointment_date);
      const sevenDaysFromNow = addDays(now, 7);
      return aptDate >= now && aptDate <= sevenDaysFromNow && apt.status !== 'completed' && apt.status !== 'cancelled';
    } catch {
      return false;
    }
  }).slice(0, 8);

  // Create some sample appointments if none exist
  const createSampleAppointment = async () => {
    const customerList = Object.values(customers);
    if (customerList.length === 0) return;

    const sampleAppointments = [
      {
        customer_id: customerList[0]?.id,
        vehicle_id: 'sample_vehicle',
        appointment_date: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
        reason: "Oil Change and Filter Replacement",
        status: "scheduled"
      },
      {
        customer_id: customerList[1]?.id || customerList[0]?.id,
        vehicle_id: 'sample_vehicle_2', 
        appointment_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow
        reason: "Brake Inspection",
        status: "scheduled"
      }
    ];

    try {
      for (const apt of sampleAppointments) {
        if (apt.customer_id) {
          await Appointment.create(apt);
        }
      }
      // Reload data
      window.location.reload();
    } catch (error) {
      console.error('Error creating sample appointments:', error);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-500 mt-1">Welcome back! Here's a summary of your shop's activity.</p>
        </div>
        <div className="flex gap-2">
            <Link to={createPageUrl('Appointments')}>
                 <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    New Appointment
                </Button>
            </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard title="Today's Appointments" value={todayAppointments.length} icon={Calendar} color="text-blue-500" />
        <StatCard title="Open Repair Orders" value={openRepairOrders.length} icon={Wrench} color="text-orange-500" />
        <StatCard title="Total Customers" value={Object.keys(customers).length} icon={Users} color="text-green-500" />
        <StatCard title="Tomorrow's Schedule" value={tomorrowAppointments.length} icon={Clock} color="text-purple-500" />
      </div>

      {/* Recent Activity Section */}
       <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Upcoming Appointments</CardTitle>
          {upcomingAppointments.length === 0 && Object.keys(customers).length > 0 && (
            <Button onClick={createSampleAppointment} variant="outline" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Sample Data
            </Button>
          )}
        </CardHeader>
        <CardContent>
            {isLoading ? (
                <p className="text-center text-gray-500 py-8">Loading appointments...</p>
            ) : upcomingAppointments.length > 0 ? (
                <div className="space-y-4">
                    {upcomingAppointments.map(apt => (
                        <div key={apt.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                            <div className="flex items-center gap-4">
                                <div className="text-center min-w-[60px]">
                                    <p className="text-sm font-medium text-blue-600">
                                        {format(new Date(apt.appointment_date), 'MMM d')}
                                    </p>
                                    <p className="text-xs text-gray-500">
                                        {format(new Date(apt.appointment_date), 'h:mm a')}
                                    </p>
                                </div>
                                <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-1">
                                        <User className="h-4 w-4 text-gray-400" />
                                        <span className="font-medium">
                                            {customers[apt.customer_id]?.full_name || 'Walk-in Customer'}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <Car className="h-4 w-4 text-gray-400" />
                                        <span className="text-sm text-gray-600">
                                            {vehicles[apt.vehicle_id] 
                                                ? `${vehicles[apt.vehicle_id].year} ${vehicles[apt.vehicle_id].make} ${vehicles[apt.vehicle_id].model}`
                                                : 'Vehicle Information Pending'
                                            }
                                        </span>
                                    </div>
                                    <p className="text-sm text-gray-600 mt-1">{apt.reason}</p>
                                </div>
                            </div>
                            <Badge className={statusColors[apt.status]}>
                                {apt.status.replace('_', ' ')}
                            </Badge>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-12">
                    <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">No upcoming appointments scheduled.</p>
                    {Object.keys(customers).length > 0 ? (
                        <Button onClick={createSampleAppointment} variant="outline">
                            <Plus className="h-4 w-4 mr-2" />
                            Add Sample Appointments
                        </Button>
                    ) : (
                        <p className="text-sm text-gray-400">Add some customers first to schedule appointments.</p>
                    )}
                </div>
            )}
        </CardContent>
      </Card>
      
    </div>
  );
}