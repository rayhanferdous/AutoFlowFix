import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import AppointmentCalendar from '../components/appointments/AppointmentCalendar';

export default function AppointmentsPage() {
    const [selectedAppointment, setSelectedAppointment] = useState(null);

    return (
        <div className="space-y-8 h-full">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Appointments</h1>
                    <p className="text-gray-500 mt-1">View and manage your shop's schedule.</p>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    New Appointment
                </Button>
            </div>

            <div className="flex-1">
                <AppointmentCalendar onAppointmentSelect={setSelectedAppointment} />
            </div>
        </div>
    );
}