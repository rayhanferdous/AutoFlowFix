
import React, { useState, useEffect, useCallback } from 'react';
import { Customer } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Plus, Search, Users as UsersIcon, UserCheck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CustomerForm from '../components/customers/CustomerForm';
import CustomerDetailView from '../components/customers/CustomerDetailView';

const CustomerListItem = ({ customer, onSelect, isSelected }) => (
    <div
        className={`p-4 border-b cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`}
        onClick={() => onSelect(customer)}
    >
        <p className="font-semibold text-gray-800">{customer.full_name}</p>
        <p className="text-sm text-gray-500">{customer.email}</p>
    </div>
);

const PortalAccountManager = () => {
    return (
        <div className="space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Customer Portal Access</CardTitle>
                    <CardDescription>
                        Customer portal now uses Base44's built-in authentication system. Customers can register and login directly using Google authentication.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="text-center py-8">
                        <p className="text-gray-500">No manual account management needed.</p>
                        <p className="text-sm text-gray-400 mt-2">Customers can register and login through the Customer Portal page.</p>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
};

export default function CustomersPage() {
    const [customers, setCustomers] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedCustomer, setSelectedCustomer] = useState(null);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    const loadCustomers = useCallback(async () => {
        setIsLoading(true);
        const data = await Customer.list('-created_date');
        setCustomers(data);
        if (!selectedCustomer && data.length > 0) {
            setSelectedCustomer(data[0]);
        } else if (selectedCustomer) {
            const refreshedCustomer = data.find(c => c.id === selectedCustomer.id);
            setSelectedCustomer(refreshedCustomer || (data.length > 0 ? data[0] : null));
        }
        setIsLoading(false);
    }, [selectedCustomer]);

    useEffect(() => {
        loadCustomers();
    }, []);

    const handleSave = () => {
        setIsFormOpen(false);
        setEditingCustomer(null);
        loadCustomers();
    };

    const handleAddCustomer = () => {
        setEditingCustomer(null);
        setIsFormOpen(true);
    };

    const handleEditCustomer = () => {
        if (selectedCustomer) {
            setEditingCustomer(selectedCustomer);
            setIsFormOpen(true);
        }
    };

    const handleDeleteCustomer = () => {
        setSelectedCustomer(null);
        loadCustomers();
    };

    const filteredCustomers = customers.filter(c =>
        c.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <>
            <div className="h-full flex flex-col">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Customer Management</h1>
                        <p className="text-gray-500 mt-1">Manage customer profiles.</p>
                    </div>
                    <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAddCustomer}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Customer
                    </Button>
                </div>

                <Tabs defaultValue="customers" className="flex-grow flex flex-col">
                    <TabsList className="mb-4">
                        <TabsTrigger value="customers"><UsersIcon className="h-4 w-4 mr-2" />Shop Customers</TabsTrigger>
                        <TabsTrigger value="accounts"><UserCheck className="h-4 w-4 mr-2" />Portal Info</TabsTrigger>
                    </TabsList>
                    <TabsContent value="customers" className="flex-grow">
                        <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6 h-full">
                            <Card className="md:col-span-1 lg:col-span-1 flex flex-col h-full">
                                <CardHeader className="p-4 border-b">
                                    <div className="relative">
                                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                                        <Input
                                            placeholder="Search customers..."
                                            className="pl-9"
                                            value={searchTerm}
                                            onChange={(e) => setSearchTerm(e.target.value)}
                                        />
                                    </div>
                                </CardHeader>
                                <CardContent className="p-0 flex-grow overflow-y-auto">
                                    {isLoading ? (
                                        <div className="p-4 space-y-4">
                                            {Array.from({ length: 10 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
                                        </div>
                                    ) : (
                                        filteredCustomers.map(customer => (
                                            <CustomerListItem
                                                key={customer.id}
                                                customer={customer}
                                                onSelect={setSelectedCustomer}
                                                isSelected={selectedCustomer?.id === customer.id}
                                            />
                                        ))
                                    )}
                                </CardContent>
                            </Card>

                            <div className="md:col-span-2 lg:col-span-3 h-full overflow-y-auto">
                                <CustomerDetailView
                                   customer={selectedCustomer}
                                   onEditCustomer={handleEditCustomer}
                                   onDeleteCustomer={handleDeleteCustomer}
                                />
                            </div>
                        </div>
                    </TabsContent>
                    <TabsContent value="accounts" className="flex-grow h-full">
                        <PortalAccountManager />
                    </TabsContent>
                </Tabs>
            </div>

            <CustomerForm
                open={isFormOpen}
                onOpenChange={setIsFormOpen}
                customer={editingCustomer}
                onSave={handleSave}
            />
        </>
    );
}
