import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { customerAuth } from '@/api/functions';
import { Loader2 } from 'lucide-react';

export default function CustomerDebugPage() {
    const [email, setEmail] = useState('finaltest@gmail.com');
    const [results, setResults] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    const checkAccount = async () => {
        setIsLoading(true);
        setResults(null);
        try {
            const response = await customerAuth({
                action: 'debug',
                email: email
            });
            setResults(response.data);
        } catch (error) {
            setResults({ error: error.message });
        }
        setIsLoading(false);
    };

    const registerAccount = async () => {
        setIsLoading(true);
        setResults(null);
        try {
            const response = await customerAuth({
                action: 'register',
                email: email,
                password: 'password123',
                customerData: {
                    full_name: 'Final Test User',
                    email: email,
                    phone_number: '555-555-5555',
                    address: '123 Final Test St'
                }
            });
            setResults(response.data);
        } catch (error) {
            setResults({ error: error.message });
        }
        setIsLoading(false);
    };

    return (
        <div className="max-w-2xl mx-auto p-6 space-y-6">
            <Card>
                <CardHeader>
                    <CardTitle>Isolated Customer Account Test</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div>
                        <Input 
                            value={email} 
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="Enter email to check"
                        />
                    </div>
                    <div className="flex gap-2">
                        <Button onClick={checkAccount} disabled={isLoading}>
                            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Check Account
                        </Button>
                        <Button onClick={registerAccount} disabled={isLoading} variant="outline">
                             {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            Register Account
                        </Button>
                    </div>
                    {results && (
                        <div className="mt-4 p-4 bg-gray-100 rounded">
                            <h3 className="font-semibold mb-2">Results:</h3>
                            <pre className="text-sm whitespace-pre-wrap">{JSON.stringify(results, null, 2)}</pre>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}