import React, { useState, useEffect } from 'react';
import { RepairOrder } from '@/api/entities';
import { Vehicle } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Car, Loader2, LogOut } from 'lucide-react';
import LoginForm from '../components/customers/LoginForm';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CustomerPortalPage() {
    const [customer, setCustomer] = useState(null);
    const [repairOrders, setRepairOrders] = useState([]);
    const [vehicles, setVehicles] = useState({});
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        // Check if customer is already logged in (e.g., from a previous page refresh)
        const loggedInCustomer = sessionStorage.getItem('currentCustomer');
        if (loggedInCustomer) {
            const customerData = JSON.parse(loggedInCustomer);
            setCustomer(customerData);
            loadCustomerData(customerData.customer_record_id);
        } else {
            setIsLoading(false);
        }
    }, []);

    const loadCustomerData = async (customerId) => {
        setIsLoading(true);
        try {
            const [vehicleList, orderList] = await Promise.all([
                Vehicle.filter({ customer_id: customerId }),
                RepairOrder.filter({ customer_id: customerId })
            ]);
            setVehicles((vehicleList || []).reduce((acc, v) => ({ ...acc, [v.id]: v }), {}));
            setRepairOrders(orderList || []);
        } catch (error) {
            console.error("Error loading customer data:", error);
        } finally {
            setIsLoading(false);
        }
    };

    const handleLoginSuccess = (customerData) => {
        setCustomer(customerData);
        loadCustomerData(customerData.customer_record_id);
    };

    const handleLogout = () => {
        sessionStorage.removeItem('currentCustomer');
        setCustomer(null);
        setRepairOrders([]);
        setVehicles({});
    };

    if (isLoading) {
        return (
            <div className="flex items-center justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin mr-3 text-gray-400" />
                <span className="text-gray-600">Loading Portal...</span>
            </div>
        );
    }
    
    if (!customer) {
        return (
             <div className="text-center p-12">
                <LoginForm onLoginSuccess={handleLoginSuccess} />
                <p className="mt-6 text-sm text-gray-600">
                    Don't have an account?{' '}
                    <Link to={createPageUrl('CustomerRegistration')} className="font-medium text-blue-600 hover:underline">
                        Register here
                    </Link>
                </p>
            </div>
        );
    }

    return (
        <div className="space-y-8">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Welcome back, {customer.full_name}!</h1>
                    <p className="text-gray-500 mt-1">Track the status of your vehicle repairs below.</p>
                </div>
                <Button variant="outline" onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                </Button>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Your Profile</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                        <div>
                            <p className="text-sm text-gray-500">Name</p>
                            <p className="font-medium">{customer.full_name}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Email</p>
                            <p className="font-medium">{customer.email}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Phone</p>
                            <p className="font-medium">{customer.phone_number || 'Not provided'}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-500">Address</p>
                            <p className="font-medium">{customer.address || 'Not provided'}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Your Vehicles</CardTitle>
                </CardHeader>
                <CardContent>
                     {Object.keys(vehicles).length === 0 ? (
                        <p className="text-gray-500">No vehicles on file.</p>
                    ) : (
                        <div className="space-y-4">
                            {Object.values(vehicles).map(vehicle => (
                                <div key={vehicle.id} className="border rounded-lg p-4">
                                    <h3 className="text-lg font-semibold">{vehicle.year} {vehicle.make} {vehicle.model}</h3>
                                    <p className="text-sm text-gray-500">License: {vehicle.license_plate}</p>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Your Repair History</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {repairOrders.length === 0 ? (
                        <p className="text-gray-500">No repair history found.</p>
                    ) : (
                        repairOrders.map(order => (
                             <div key={order.id} className="border rounded-lg p-4">
                                <div className="flex justify-between items-center">
                                    <p className="font-semibold">{vehicles[order.vehicle_id]?.make} {vehicles[order.vehicle_id]?.model}</p>
                                    <Badge>{order.status}</Badge>
                                </div>
                                <p className="text-right font-bold text-green-600 mt-2">${order.total_amount}</p>
                             </div>
                        ))
                    )}
                </CardContent>
            </Card>
        </div>
    );
}