import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Customers from "./Customers";

import Appointments from "./Appointments";

import RepairOrders from "./RepairOrders";

import Invoices from "./Invoices";

import Inventory from "./Inventory";

import WeeklySpecials from "./WeeklySpecials";

import AboutUs from "./AboutUs";

import CustomerPortal from "./CustomerPortal";

import CustomerRegistration from "./CustomerRegistration";

import TestRegistration from "./TestRegistration";

import CustomerDebug from "./CustomerDebug";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Customers: Customers,
    
    Appointments: Appointments,
    
    RepairOrders: RepairOrders,
    
    Invoices: Invoices,
    
    Inventory: Inventory,
    
    WeeklySpecials: WeeklySpecials,
    
    AboutUs: AboutUs,
    
    CustomerPortal: CustomerPortal,
    
    CustomerRegistration: CustomerRegistration,
    
    TestRegistration: TestRegistration,
    
    CustomerDebug: CustomerDebug,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Customers" element={<Customers />} />
                
                <Route path="/Appointments" element={<Appointments />} />
                
                <Route path="/RepairOrders" element={<RepairOrders />} />
                
                <Route path="/Invoices" element={<Invoices />} />
                
                <Route path="/Inventory" element={<Inventory />} />
                
                <Route path="/WeeklySpecials" element={<WeeklySpecials />} />
                
                <Route path="/AboutUs" element={<AboutUs />} />
                
                <Route path="/CustomerPortal" element={<CustomerPortal />} />
                
                <Route path="/CustomerRegistration" element={<CustomerRegistration />} />
                
                <Route path="/TestRegistration" element={<TestRegistration />} />
                
                <Route path="/CustomerDebug" element={<CustomerDebug />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}