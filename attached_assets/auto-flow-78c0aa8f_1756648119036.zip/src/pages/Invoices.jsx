import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import InvoiceList from '../components/invoices/InvoiceList';

export default function InvoicesPage() {
    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Invoices</h1>
                    <p className="text-gray-500 mt-1">Manage and track all customer invoices.</p>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    New Invoice
                </Button>
            </div>

            <InvoiceList />
        </div>
    );
}