
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { customerAuth } from '@/api/functions';

export default function TestRegistrationPage() {
    const [formData, setFormData] = useState({
        full_name: 'Test Customer',
        email: 'test@example.com',
        phone_number: '123-456-7890',
        address: '123 Test Street',
        password: 'test123',
        confirmPassword: 'test123'
    });
    
    const [isLoading, setIsLoading] = useState(false);
    const [messages, setMessages] = useState([]);
    const [success, setSuccess] = useState(false);

    const addMessage = (message) => {
        setMessages(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`]);
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessages([]);
        setIsLoading(true);
        
        addMessage('Starting registration process...');

        try {
            // Validation
            if (formData.password !== formData.confirmPassword) {
                addMessage('❌ Passwords do not match');
                setIsLoading(false);
                return;
            }
            
            addMessage('✅ Password validation passed');
            
            const { confirmPassword, ...registrationData } = formData;
            
            addMessage('📤 Calling customerAuth function...');
            
            const response = await customerAuth({
                action: 'register',
                email: registrationData.email,
                password: registrationData.password,
                customerData: registrationData
            });

            addMessage('📥 Got response from customerAuth function');
            addMessage(`Response status: ${response.status}`);
            addMessage(`Response data: ${JSON.stringify(response.data)}`);

            if (response.data.success) {
                addMessage('✅ Registration successful!');
                setSuccess(true);
            } else {
                addMessage(`❌ Registration failed: ${response.data.message}`);
            }
        } catch (error) {
            addMessage(`❌ Error occurred: ${error.message}`);
            console.error('Registration error:', error);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-4">
            <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl font-bold mb-6">Test Customer Registration</h1>
                
                <div className="grid md:grid-cols-2 gap-6">
                    {/* Registration Form */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Registration Form</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <form onSubmit={handleSubmit} className="space-y-4">
                                <div>
                                    <Label htmlFor="full_name">Full Name</Label>
                                    <Input
                                        id="full_name"
                                        name="full_name"
                                        value={formData.full_name}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                
                                <div>
                                    <Label htmlFor="email">Email</Label>
                                    <Input
                                        id="email"
                                        name="email"
                                        type="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                
                                <div>
                                    <Label htmlFor="phone_number">Phone</Label>
                                    <Input
                                        id="phone_number"
                                        name="phone_number"
                                        value={formData.phone_number}
                                        onChange={handleChange}
                                    />
                                </div>
                                
                                <div>
                                    <Label htmlFor="address">Address</Label>
                                    <Input
                                        id="address"
                                        name="address"
                                        value={formData.address}
                                        onChange={handleChange}
                                    />
                                </div>
                                
                                <div>
                                    <Label htmlFor="password">Password</Label>
                                    <Input
                                        id="password"
                                        name="password"
                                        type="password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>
                                
                                <div>
                                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                                    <Input
                                        id="confirmPassword"
                                        name="confirmPassword"
                                        type="password"
                                        value={formData.confirmPassword}
                                        onChange={handleChange}
                                        required
                                    />
                                </div>

                                <Button type="submit" disabled={isLoading} className="w-full">
                                    {isLoading ? (
                                        <>
                                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                            Registering...
                                        </>
                                    ) : (
                                        'Test Registration'
                                    )}
                                </Button>
                            </form>
                        </CardContent>
                    </Card>

                    {/* Debug Messages */}
                    <Card>
                        <CardHeader>
                            <CardTitle>Debug Messages</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <div className="bg-gray-100 p-4 rounded-lg h-96 overflow-y-auto">
                                {messages.length === 0 ? (
                                    <p className="text-gray-500">Submit the form to see debug messages...</p>
                                ) : (
                                    <div className="space-y-2">
                                        {messages.map((message, index) => (
                                            <div key={index} className="text-sm font-mono">
                                                {message}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                            
                            {success && (
                                <div className="mt-4 p-4 bg-green-100 text-green-800 rounded-lg">
                                    Registration successful!
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
