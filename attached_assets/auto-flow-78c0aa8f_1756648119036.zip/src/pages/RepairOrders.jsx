import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import RepairOrderBoard from '../components/repairorders/RepairOrderBoard';

export default function RepairOrdersPage() {
    return (
        <div className="space-y-8 h-full flex flex-col">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Repair Orders</h1>
                    <p className="text-gray-500 mt-1">Create estimates and manage ongoing jobs.</p>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="h-4 w-4 mr-2" />
                    New Repair Order
                </Button>
            </div>

            <div className="flex-1 overflow-hidden">
                <RepairOrderBoard />
            </div>
        </div>
    );
}