import React, { useState, useEffect } from 'react';
import { Special } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tag, Plus, Edit, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import SpecialForm from '../components/specials/SpecialForm';

export default function WeeklySpecialsPage() {
    const [specials, setSpecials] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isFormOpen, setIsFormOpen] = useState(false);
    const [editingSpecial, setEditingSpecial] = useState(null);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [specialToDelete, setSpecialToDelete] = useState(null);

    const fetchSpecials = async () => {
        setIsLoading(true);
        const allSpecials = await Special.list('-created_date');
        setSpecials(allSpecials);
        setIsLoading(false);
    };

    useEffect(() => {
        fetchSpecials();
    }, []);
    
    const handleSave = () => {
        setIsFormOpen(false);
        fetchSpecials();
    };

    const handleAdd = () => {
        setEditingSpecial(null);
        setIsFormOpen(true);
    };

    const handleEdit = (special) => {
        setEditingSpecial(special);
        setIsFormOpen(true);
    };

    const handleDeleteClick = (special) => {
        setSpecialToDelete(special);
        setShowDeleteConfirm(true);
    };

    const handleDeleteConfirm = async () => {
        if (specialToDelete) {
            await Special.delete(specialToDelete.id);
            setShowDeleteConfirm(false);
            setSpecialToDelete(null);
            fetchSpecials();
        }
    };
    
    const toggleActive = async (special) => {
        await Special.update(special.id, { is_active: !special.is_active });
        fetchSpecials();
    };

    return (
        <>
            <div className="space-y-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <h1 className="text-3xl font-bold text-gray-900">Manage Special Offers</h1>
                        <p className="text-gray-500 mt-1">Create, edit, and manage your weekly specials.</p>
                    </div>
                    <Button className="bg-blue-600 hover:bg-blue-700" onClick={handleAdd}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add New Special
                    </Button>
                </div>

                {isLoading ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {Array.from({ length: 3 }).map((_, i) => (
                            <Card key={i} className="animate-pulse">
                                <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                                <CardHeader><div className="h-6 bg-gray-200 rounded w-3/4"></div></CardHeader>
                                <CardContent><div className="h-10 bg-gray-200 rounded w-full"></div></CardContent>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {specials.map(special => (
                            <Card key={special.id} className={`overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 ${!special.is_active ? 'bg-gray-50 opacity-60' : ''}`}>
                                <img src={special.image_url || 'https://images.unsplash.com/photo-1517524206127-48bbd363f357?q=80&w=2070&auto=format&fit=crop'} alt={special.title} className="w-full h-48 object-cover" />
                                <CardHeader>
                                    <CardTitle className="text-xl text-blue-700">{special.title}</CardTitle>
                                    {special.valid_until && (
                                         <CardDescription className="flex items-center gap-2 text-sm">
                                            <Tag className="h-4 w-4" />
                                            Valid until {format(new Date(special.valid_until), 'MMMM d, yyyy')}
                                        </CardDescription>
                                    )}
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-600">{special.description}</p>
                                </CardContent>
                                <CardFooter className="bg-gray-50/50 p-4 flex justify-between items-center">
                                    <div className="flex items-center gap-2">
                                        <Switch checked={special.is_active} onCheckedChange={() => toggleActive(special)} />
                                        <span className="text-sm font-medium">{special.is_active ? 'Active' : 'Inactive'}</span>
                                    </div>
                                    <div className="flex gap-2">
                                        <Button variant="outline" size="sm" onClick={() => handleEdit(special)}><Edit className="h-3 w-3 mr-1"/> Edit</Button>
                                        <Button variant="destructive" size="sm" onClick={() => handleDeleteClick(special)}><Trash2 className="h-3 w-3 mr-1"/> Delete</Button>
                                    </div>
                                </CardFooter>
                            </Card>
                        ))}
                    </div>
                )}
            </div>
            
            <SpecialForm 
                open={isFormOpen}
                onOpenChange={setIsFormOpen}
                special={editingSpecial}
                onSave={handleSave}
            />

            <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete the special offer.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleDeleteConfirm}>Delete</AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </>
    );
}