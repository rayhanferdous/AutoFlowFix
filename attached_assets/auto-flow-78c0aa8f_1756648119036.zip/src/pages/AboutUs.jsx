import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Wrench, ShieldCheck } from 'lucide-react';

const FeatureCard = ({ icon: Icon, title, children }) => (
    <div className="flex items-start gap-4">
        <div className="bg-blue-100 text-blue-600 p-3 rounded-lg">
            <Icon className="h-6 w-6" />
        </div>
        <div>
            <h3 className="text-lg font-semibold">{title}</h3>
            <p className="text-gray-600 mt-1">{children}</p>
        </div>
    </div>
);

export default function AboutUsPage() {
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">About AutoFlow Garage</h1>
                <p className="text-gray-500 mt-1">Your trusted partner in automotive care.</p>
            </div>

            <div className="grid lg:grid-cols-5 gap-8">
                <div className="lg:col-span-3 space-y-6">
                    <Card>
                        <CardContent className="p-6">
                            <h2 className="text-2xl font-bold text-gray-800 mb-4">Our Story</h2>
                            <p className="text-gray-600 mb-4">
                                Founded in 2010, AutoFlow Garage started as a small, family-owned workshop with a simple mission: to provide honest, reliable, and high-quality auto repair services to our community. Over the years, we've grown into a state-of-the-art facility, but our core values remain the same.
                            </p>
                            <p className="text-gray-600">
                                We believe in transparency and trust. That's why we invested in the latest technology to give you a clear view of your vehicle's health and empower you to make informed decisions about its care. Our team of certified technicians is passionate about cars and dedicated to delivering exceptional service, every time.
                            </p>
                        </CardContent>
                    </Card>

                    <Card>
                         <CardContent className="p-6 space-y-6">
                             <FeatureCard icon={Users} title="Expert Technicians">
                                Our team is ASE-certified and continuously trained on the latest vehicle models and repair techniques.
                             </FeatureCard>
                             <FeatureCard icon={Wrench} title="Advanced Diagnostics">
                                We use cutting-edge diagnostic tools to accurately identify issues and ensure effective repairs.
                             </FeatureCard>
                             <FeatureCard icon={ShieldCheck} title="Quality Guarantee">
                                We stand by our work with a 24-month/24,000-mile warranty on all parts and labor.
                             </FeatureCard>
                         </CardContent>
                    </Card>
                </div>

                <div className="lg:col-span-2">
                    <Card className="overflow-hidden">
                        <img 
                            src="https://images.unsplash.com/photo-1553859943-a0c8a325d3a5?q=80&w=1974&auto=format&fit=crop" 
                            alt="Our Garage" 
                            className="w-full h-64 object-cover"
                        />
                        <div className="p-6">
                            <h3 className="text-xl font-semibold mb-3">Visit Us</h3>
                            <p className="text-gray-600 font-semibold">AutoFlow Garage</p>
                            <p className="text-gray-600">123 Service Lane</p>
                            <p className="text-gray-600">Anytown, USA 12345</p>
                            <p className="text-gray-600 mt-2">(555) 123-4567</p>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
}